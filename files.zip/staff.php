<?php
session_start();

require_once __DIR__ . '/app/controllers/StaffController.php';

$controller = new StaffController();
$action     = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    match ($action) {
        'save'   => $controller->save(),
        'delete' => $controller->delete(),
        'toggle' => $controller->toggle(),
        default  => $controller->index(),
    };
} else {
    match ($action) {
        'add'    => $controller->showAdd(),
        'edit'   => $controller->showEdit(),
        'delete' => $controller->showDelete(),
        default  => $controller->index(),
    };
}
