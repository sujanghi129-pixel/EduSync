<?php
require_once __DIR__ . '/../../shared/db.php';
require_once __DIR__ . '/../models/Staff.php';

class StaffController {

    /* ══════════════════════════════════════
       SHOW: staff list
    ══════════════════════════════════════ */
    public function index(): void {
        $staff = Staff::getAll();
        require __DIR__ . '/../../views/staff/index.php';
    }

    /* ══════════════════════════════════════
       SHOW: add form
    ══════════════════════════════════════ */
    public function showAdd(): void {
        $error = $_SESSION['error'] ?? null;
        $old   = $_SESSION['old']   ?? [];
        unset($_SESSION['error'], $_SESSION['old']);
        require __DIR__ . '/../../views/staff/add.php';
    }

    /* ══════════════════════════════════════
       SHOW: edit form
    ══════════════════════════════════════ */
    public function showEdit(): void {
        $id    = (int)($_GET['id'] ?? 0);
        $staff = Staff::getById($id);
        if (!$staff) { $this->redirect(''); return; }

        $error = $_SESSION['error'] ?? null;
        $old   = $_SESSION['old']   ?? [];
        unset($_SESSION['error'], $_SESSION['old']);
        require __DIR__ . '/../../views/staff/edit.php';
    }

    /* ══════════════════════════════════════
       SHOW: delete confirm
    ══════════════════════════════════════ */
    public function showDelete(): void {
        $id    = (int)($_GET['id'] ?? 0);
        $staff = Staff::getById($id);
        if (!$staff) { $this->redirect(''); return; }

        $assignedToClass = Staff::isAssignedToClass($id);
        require __DIR__ . '/../../views/staff/delete.php';
    }

    /* ══════════════════════════════════════
       POST: save (create or update)
    ══════════════════════════════════════ */
    public function save(): void {
        $staffId  = (int)($_POST['staffId'] ?? 0);
        $fullName = trim($_POST['fullName'] ?? '');
        $email    = strtolower(trim($_POST['email'] ?? ''));
        $username = strtolower(trim($_POST['username'] ?? ''));
        $password = $_POST['password'] ?? '';
        $role     = $_POST['role'] ?? '';
        $isAdd    = $staffId === 0;

        $error = null;
        if (!$fullName)                                      $error = 'Full name is required.';
        elseif (!$email)                                     $error = 'Email is required.';
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL))  $error = 'Enter a valid email address.';
        elseif (!$username)                                  $error = 'Username is required.';
        elseif (!$role)                                      $error = 'Please select a role.';
        elseif ($isAdd && !$password)                        $error = 'Password is required for new accounts.';
        elseif ($password && strlen($password) < 6)         $error = 'Password must be at least 6 characters.';
        elseif (Staff::emailExists($email, $staffId))        $error = 'That email is already in use.';
        elseif (Staff::usernameExists($username, $staffId))  $error = 'That username is already taken.';

        if ($error) {
            $_SESSION['error'] = $error;
            $_SESSION['old']   = compact('fullName', 'email', 'username', 'role');
            $this->redirect($isAdd ? 'add' : "edit&id=$staffId");
            return;
        }

        $data = compact('fullName', 'email', 'username', 'password', 'role', 'staffId');
        $isAdd ? Staff::create($data) : Staff::update($data);

        $_SESSION['toast'] = $isAdd ? 'Staff account created.' : 'Staff account updated.';
        $this->redirect('');
    }

    /* ══════════════════════════════════════
       POST: delete
    ══════════════════════════════════════ */
    public function delete(): void {
        $id = (int)($_POST['staffId'] ?? 0);

        if (Staff::isAssignedToClass($id)) {
            $_SESSION['toast_error'] = 'Cannot delete: staff is assigned to an active class.';
            $this->redirect("delete&id=$id");
            return;
        }

        Staff::delete($id);
        $_SESSION['toast'] = 'Staff account permanently deleted.';
        $this->redirect('');
    }

    /* ══════════════════════════════════════
       POST: toggle active / inactive
    ══════════════════════════════════════ */
    public function toggle(): void {
        $id    = (int)($_POST['staffId'] ?? 0);
        $staff = Staff::getById($id);

        if ($staff['isActive'] && Staff::isAssignedToClass($id)) {
            $_SESSION['toast_error'] = "Cannot deactivate: {$staff['fullName']} is assigned to an active class.";
            $this->redirect('');
            return;
        }

        Staff::toggle($id);
        $newState = $staff['isActive'] ? 'deactivated' : 'activated';
        $_SESSION['toast'] = "Account {$newState}.";
        $this->redirect('');
    }

    /* ── helper ── */
    private function redirect(string $action): void {
        $url = 'staff.php' . ($action ? "?action=$action" : '');
        header("Location: $url");
        exit;
    }
}
