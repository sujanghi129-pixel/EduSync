<?php
require_once __DIR__ . '/../../shared/db.php';

class Staff {

    /* ── GET ALL ── */
    public static function getAll(): array {
        $pdo  = db();
        $stmt = $pdo->query("SELECT * FROM tblStaff ORDER BY staffId ASC");
        return $stmt->fetchAll();
    }

    /* ── GET BY ID ── */
    public static function getById(int $id): array|false {
        $pdo  = db();
        $stmt = $pdo->prepare("SELECT * FROM tblStaff WHERE staffId = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    /* ── CREATE ── */
    public static function create(array $data): bool {
        $pdo  = db();
        $stmt = $pdo->prepare("
            INSERT INTO tblStaff (fullName, email, username, passwordHash, role, isActive, createdAt)
            VALUES (?, ?, ?, ?, ?, 1, NOW())
        ");
        return $stmt->execute([
            $data['fullName'],
            $data['email'],
            $data['username'],
            password_hash($data['password'], PASSWORD_BCRYPT),
            $data['role']
        ]);
    }

    /* ── UPDATE ── */
    public static function update(array $data): bool {
        $pdo = db();
        if (!empty($data['password'])) {
            $stmt = $pdo->prepare("
                UPDATE tblStaff
                SET fullName=?, email=?, username=?, passwordHash=?, role=?
                WHERE staffId=?
            ");
            return $stmt->execute([
                $data['fullName'],
                $data['email'],
                $data['username'],
                password_hash($data['password'], PASSWORD_BCRYPT),
                $data['role'],
                $data['staffId']
            ]);
        } else {
            $stmt = $pdo->prepare("
                UPDATE tblStaff
                SET fullName=?, email=?, username=?, role=?
                WHERE staffId=?
            ");
            return $stmt->execute([
                $data['fullName'],
                $data['email'],
                $data['username'],
                $data['role'],
                $data['staffId']
            ]);
        }
    }

    /* ── DELETE ── */
    public static function delete(int $id): bool {
        $pdo  = db();
        $stmt = $pdo->prepare("DELETE FROM tblStaff WHERE staffId = ?");
        return $stmt->execute([$id]);
    }

    /* ── TOGGLE ACTIVE ── */
    public static function toggle(int $id): bool {
        $pdo  = db();
        $stmt = $pdo->prepare("UPDATE tblStaff SET isActive = NOT isActive WHERE staffId = ?");
        return $stmt->execute([$id]);
    }

    /* ── IS ASSIGNED TO ACTIVE CLASS ── */
    public static function isAssignedToClass(int $id): bool {
        $pdo  = db();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tblClass WHERE classTeacherID = ? AND isActive = 1");
        $stmt->execute([$id]);
        return $stmt->fetchColumn() > 0;
    }

    /* ── EMAIL EXISTS ── */
    public static function emailExists(string $email, int $excludeId = 0): bool {
        $pdo  = db();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tblStaff WHERE email = ? AND staffId != ?");
        $stmt->execute([$email, $excludeId]);
        return $stmt->fetchColumn() > 0;
    }

    /* ── USERNAME EXISTS ── */
    public static function usernameExists(string $username, int $excludeId = 0): bool {
        $pdo  = db();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tblStaff WHERE username = ? AND staffId != ?");
        $stmt->execute([$username, $excludeId]);
        return $stmt->fetchColumn() > 0;
    }
}
