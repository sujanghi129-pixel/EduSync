<!DOCTYPE html>
<html lang="en" data-theme="system">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Staff — EduSync</title>
<link rel="stylesheet" href="views/staff/style.css">
</head>
<body>
<div class="overlay" id="overlay"></div>
<nav class="topnav" id="topnav"></nav>
<div class="app-layout">
  <aside class="sidebar" id="sidebar"></aside>
  <main class="content">

    <div class="page-eyebrow">Admin · Sujan Ghimire</div>
    <div class="page-title">Add New Staff</div>
    <div class="page-sub">Create a new staff account and assign a role.</div>

    <div class="card" style="max-width:600px;">

      <?php if (!empty($error)): ?>
        <div class="callout callout-danger" style="margin-bottom:16px;">⚠️ <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST" action="staff.php?action=save">
        <input type="hidden" name="staffId" value="0">

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Full Name <span class="req">*</span></label>
            <input class="form-input" name="fullName" placeholder="e.g. Jane Smith"
              value="<?= htmlspecialchars($old['fullName'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Email <span class="req">*</span></label>
            <input class="form-input" name="email" type="email" placeholder="jane@school.com"
              value="<?= htmlspecialchars($old['email'] ?? '') ?>">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Username <span class="req">*</span></label>
            <input class="form-input" name="username" placeholder="jane.smith"
              value="<?= htmlspecialchars($old['username'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">Password <span class="req">*</span></label>
            <input class="form-input" name="password" type="password" placeholder="Min 6 characters">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Role <span class="req">*</span></label>
          <select class="form-select" name="role">
            <option value="">Select role…</option>
            <?php foreach (['Administrator','Teacher','Headteacher'] as $r): ?>
              <option value="<?= $r ?>" <?= ($old['role'] ?? '') === $r ? 'selected' : '' ?>><?= $r ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="modal-footer" style="padding:16px 0 0;border-top:1px solid var(--border);margin-top:8px;">
          <a href="staff.php" class="btn btn-ghost">Cancel</a>
          <button type="submit" class="btn btn-primary">Save Staff</button>
        </div>
      </form>

    </div>
  </main>
</div>
<script src="shared/auth.js"></script>
</body>
</html>
