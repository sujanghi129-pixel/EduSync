<?php
/**
 * Call requireLogin() at the top of every router (staff.php, students.php etc.)
 * to protect pages from unauthenticated access.
 */
function requireLogin(): void {
    if (session_status() === PHP_SESSION_NONE) session_start();

    if (empty($_SESSION['user'])) {
        header('Location: ' . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/index.php');
        exit;
    }
}

function currentUser(): array {
    return $_SESSION['user'] ?? [];
}
