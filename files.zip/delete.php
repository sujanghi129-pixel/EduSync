<!DOCTYPE html>
<html lang="en" data-theme="system">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Delete Staff — EduSync</title>
<link rel="stylesheet" href="views/staff/style.css">
</head>
<body>
<div class="overlay" id="overlay"></div>
<nav class="topnav" id="topnav"></nav>
<div class="app-layout">
  <aside class="sidebar" id="sidebar"></aside>
  <main class="content">

    <div class="page-eyebrow">Admin · Sujan Ghimire</div>
    <div class="page-title">Delete Staff</div>
    <div class="page-sub">Review before permanently removing this account.</div>

    <div class="card" style="max-width:480px;">

      <?php if (!empty($_SESSION['toast_error'])): ?>
        <div class="callout callout-danger" style="margin-bottom:16px;">
          ⚠️ <?= htmlspecialchars($_SESSION['toast_error']) ?>
        </div>
        <?php unset($_SESSION['toast_error']); ?>
      <?php endif; ?>

      <?php $roleColor = ['Administrator'=>'badge-blue','Teacher'=>'badge-yellow','Headteacher'=>'badge-green']; ?>
      <div style="display:flex;gap:12px;align-items:flex-start;padding:12px;background:var(--surface2);border-radius:8px;margin-bottom:16px;">
        <div style="flex:1;">
          <div style="font-weight:600;font-size:.95rem;"><?= htmlspecialchars($staff['fullName']) ?></div>
          <div style="color:var(--text-muted);font-size:.8rem;">
            <?= htmlspecialchars($staff['email']) ?> · <code><?= htmlspecialchars($staff['username']) ?></code>
          </div>
          <div style="margin-top:6px;">
            <span class="badge <?= $roleColor[$staff['role']] ?? 'badge-gray' ?>"><?= htmlspecialchars($staff['role']) ?></span>
            <?php if ($staff['isActive']): ?>
              <span class="badge badge-green" style="margin-left:4px;">● Active</span>
            <?php else: ?>
              <span class="badge badge-red" style="margin-left:4px;">● Inactive</span>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <p style="color:var(--text-muted);font-size:.875rem;margin-bottom:14px;">
        Permanently delete <strong><?= htmlspecialchars($staff['fullName']) ?></strong>? This cannot be undone.
      </p>

      <div class="callout callout-warn">
        <span>⚠️</span>
        <span>Under GDPR, consider <strong>deactivating</strong> instead of deleting to preserve attendance audit history.</span>
      </div>

      <?php if ($assignedToClass): ?>
        <div class="callout callout-danger" style="margin-top:10px;">
          <span>🚫</span>
          <span>This staff member is assigned to an active class. <strong>Reassign the class before deleting.</strong></span>
        </div>
      <?php endif; ?>

      <div class="modal-footer" style="padding:16px 0 0;border-top:1px solid var(--border);margin-top:16px;">
        <a href="staff.php" class="btn btn-ghost">Cancel</a>

        <?php if ($staff['isActive'] && !$assignedToClass): ?>
          <form method="POST" action="staff.php?action=toggle" style="display:inline;">
            <input type="hidden" name="staffId" value="<?= $staff['staffId'] ?>">
            <button type="submit" class="btn btn-ghost">Deactivate Instead</button>
          </form>
        <?php endif; ?>

        <form method="POST" action="staff.php?action=delete" style="display:inline;">
          <input type="hidden" name="staffId" value="<?= $staff['staffId'] ?>">
          <button type="submit" class="btn btn-danger" <?= $assignedToClass ? 'disabled' : '' ?>>
            Delete Permanently
          </button>
        </form>
      </div>

    </div>
  </main>
</div>
<script src="shared/auth.js"></script>
</body>
</html>
