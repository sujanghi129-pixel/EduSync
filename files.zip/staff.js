// Client-side search and filter for the staff table
function filterTable() {
  const q      = document.getElementById('searchInput').value.toLowerCase();
  const role   = document.getElementById('roleFilter').value;
  const status = document.getElementById('statusFilter').value;

  document.querySelectorAll('#staffTable tbody tr[data-name]').forEach(row => {
    const matchQ      = !q      || (row.dataset.name + row.dataset.email + row.dataset.username).includes(q);
    const matchRole   = !role   || row.dataset.role   === role;
    const matchStatus = !status || row.dataset.active === status;
    row.style.display = (matchQ && matchRole && matchStatus) ? '' : 'none';
  });
}

document.getElementById('searchInput').addEventListener('input',  filterTable);
document.getElementById('roleFilter').addEventListener('change',  filterTable);
document.getElementById('statusFilter').addEventListener('change', filterTable);

// Auto-hide toast after 4 seconds
const toast = document.getElementById('toastMsg');
if (toast) setTimeout(() => toast.style.display = 'none', 4000);
